package practica3.ejercicio01.a; // Indica aquí el nombre del paquete que utilizas.

public class ExcepcionFechaInvalida extends Exception {

    private static final long serialVersionUID = 1L;

}
