package practica4.part1;


public class act02 {
	public static void main(String[] args) {
		permutaciones(4);
	}

	public static void permutaciones(int n) {
		int[] disponibles = new int[n];
		// Rellenar disponibles
		int num = 1;
		for (int i = 0; i < n; i++, num++)
			disponibles[i] = num;
		permutaciones(disponibles, "");

	}

	private static void permutaciones(int[] disponibles, String prefijo) {
		if (disponibles.length == 0) { // Caso base: escribir el prefijo
			System.out.println(prefijo);
		} else { // Caso general
			int[] auxiliar = new int[disponibles.length-1 ];
			int pos=0;
			for (int e : disponibles) {
					if (pos<auxiliar.length)
						auxiliar[pos++]=e;
					
				
					
				// Rellenar auxiliar con los disponibles distintos de e

				permutaciones(auxiliar, prefijo + e);
			}
		}

	}

}
